#!/bin/bash

read -p "Enter the file name remove blank lines:" fname
grep -v "^$" $fname > temp.txt
mv temp.txt $fname
echo "$fname blank is replaced"
