#!/bin/bash

read -p "Enter the file name to remove the duplicate:" fname
sort -u $fname > temp.txt
mv temp.txt $fname
