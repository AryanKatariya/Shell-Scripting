#!/bin/bash

function help(){
	echo "-d DOMAIN.TLD: Provide domain as target"
	echo "-w WORDLIST: Provide subdomain list as a file"
	echo "-h/--help: help"
}

function run(){
	while read sub;do
		if host -t a "$sub.$domain" &> /dev/null;then
			echo "$sub.$domain"
		fi
	done < $wordlist
}
case $1 in
	"-d")
		domain=$2
		wordlist=$4

		case $3 in
			"-w")				
				if [ ! -s $wordlist ];then
					echo "Provide wordlist file with subdomain lists, use -h/--h"
					exit 128
				fi
				
				if [ -z $domain ];then
					echo "Provide domain, use -h/--help"
					exit 127
				fi		
				;;
			*)
				echo "Error : $3 invalid arguments, use -h/--help"
				;;
		esac


		run
		;;
	"-h"|"--help")
		help
		;;
	*)
		echo "Error : $1 invalid arguments, use -h/--help"
		;;
esac
