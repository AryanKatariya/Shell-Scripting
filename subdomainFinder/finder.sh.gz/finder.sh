#!/bin/bash


function help() {
    echo "-d DOMAIN.TLD : Provide domain as target"
    echo "-h/--help : Display help"
}


function run() {
    while read sub; do
        if host -t a "$sub.$domain" &> /dev/null; then
            echo "$sub.$domain is available"
        fi
    done < "$wordfile"
}

while [[ $# -gt 0 ]]; do
    case $1 in
        "-d")
            domain=$2
            shift 2
            ;;
        "-w")
            wordfile=$2
            shift 2
            ;;
        "-h"|"--help")
            help
            exit 0
            ;;
        *)
            echo "Error: $1 is an invalid argument, use -h or --help for usage information"
            exit 1
            ;;
    esac
done

if [ -z "$domain" ] || [ -z "$wordfile" ]; then
    echo "Error: Both domain name and wordfile are required"
    help
    exit 1
fi

if [ ! -f "$wordfile" ]; then
    echo "Error: Wordfile '$wordfile' not found"
    exit 1
fi

run

